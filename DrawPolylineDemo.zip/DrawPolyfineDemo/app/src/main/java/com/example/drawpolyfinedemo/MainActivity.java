package com.example.drawpolyfinedemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Button;
import android.graphics.Color;
import android.widget.Toast;
import java.util.List;
import java.util.ArrayList;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, SeekBar.OnSeekBarChangeListener {

    private Handler mHander=new Handler();

    GoogleMap Gmap;
    SeekBar seekWidth,seekRed,seekGreen,seekBlue;
    Button btDraw,btClear;
    Polyline polyline=null;
    List<LatLng> latLngList=new ArrayList<>();
    List<Marker> markerList=new ArrayList<>();
    int red=0,green=0,blue=0;
    Location cureentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE=101;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //cureent location code
        fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(this);
        fetchLastLocation();

        //assign Variable

        seekWidth=findViewById(R.id.seek_width);
        seekRed=findViewById(R.id.seek_red);
        seekBlue=findViewById(R.id.seek_blue);
        seekGreen=findViewById(R.id.seek_green);
        btDraw=findViewById(R.id.bt_draw);
        btClear=findViewById(R.id.bt_clear);
        //Initialize SupportMapFragement
        SupportMapFragment supportMapFragment=(SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.google_map);
        supportMapFragment.getMapAsync(this);
//        btDraw.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//              //  Draw Polyline on Map
//                if(polyline !=null) polyline.remove();
//                //create a Polyline
//                PolylineOptions polylineOptions=new PolylineOptions().addAll(latLngList).clickable(true);
//                polyline=Gmap.addPolyline(polylineOptions);
//                polyline.setColor(Color.rgb(red,green,blue));
//                setWidth();
//            }
//        });
        btClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(polyline!=null) polyline.remove();
                for(Marker marker:markerList) marker.remove();
                latLngList.clear();
                markerList.clear();
                seekWidth.setProgress(3);
                seekBlue.setProgress(0);
                seekGreen.setProgress(0);
                seekRed.setProgress(0);
            }
        });
        seekRed.setOnSeekBarChangeListener(this);
        seekGreen.setOnSeekBarChangeListener(this);
        seekBlue.setOnSeekBarChangeListener(this);
    }
    public void startLocationUpdate(View v){
       mtoastRunnable.run();
    }
    public void stopLocationUpdate(View v){
        mHander.removeCallbacks(mtoastRunnable);
    }
    private Runnable mtoastRunnable=new Runnable() {
        @Override
        public void run() {
            Toast.makeText(MainActivity.this, "This is delayed", Toast.LENGTH_SHORT).show();
            mHander.postDelayed(this, 5000);
            fetchLastLocation();
            if(cureentLocation!=null){
                LatLng latLng= new LatLng(cureentLocation.getLatitude(),cureentLocation.getLongitude());
                MarkerOptions markerOptions1=new MarkerOptions().position(latLng).title("I am Here");
                Gmap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
                Gmap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,20));
               // Gmap.addMarker(markerOptions1);
                latLngList.add(latLng);
                //Marker marker1=Gmap.addMarker(markerOptions1);
               // markerList.add(marker1);
                if(polyline !=null) polyline.remove();
                //create a Polyline
                PolylineOptions polylineOptions=new PolylineOptions().addAll(latLngList).clickable(true);
                polyline=Gmap.addPolyline(polylineOptions);
                polyline.setColor(Color.rgb(red,green,blue));
                setWidth();
            }
        }
    };
    LocationCallback lLocationCallback = new LocationCallback(){
        @Override
        public void onLocationResult(LocationResult locationResult) {
        }
    };

    private void fetchLastLocation() {
        if(ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new  String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
            return;
        }
        LocationRequest mLocationRequest=new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(0);
        fusedLocationProviderClient.requestLocationUpdates(mLocationRequest,lLocationCallback, Looper.myLooper());
        Task<Location> task=fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location !=null){
                    cureentLocation=location;
                    Toast.makeText(getApplicationContext(),cureentLocation.getLatitude()+""+cureentLocation.getLongitude(),Toast.LENGTH_SHORT).show();
                    SupportMapFragment supportMapFragment=(SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.google_map);
                    supportMapFragment.getMapAsync(MainActivity.this);
                }
            }
        });
    }


    private void setWidth() {
        seekWidth.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                //get seekbar progress
                int width=seekWidth.getProgress();
                if(polyline!=null)
                    //set polyline width
                    polyline.setWidth(width);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        if(cureentLocation!=null){
        LatLng latLng= new LatLng(cureentLocation.getLatitude(),cureentLocation.getLongitude());
        MarkerOptions markerOptions1=new MarkerOptions().position(latLng).title("I am Here");
        googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,20));
        googleMap.addMarker(markerOptions1);
        latLngList.add(latLng);
        Marker marker1=Gmap.addMarker(markerOptions1);
        markerList.add(marker1);
        System.out.print("hello");
        }
        Gmap=googleMap;
//        googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
//            @Override
//            public void onMapClick(LatLng latLng) {
//                //Create MarkerOption
//                MarkerOptions markerOptions=new MarkerOptions().position(latLng);
//                //create Marker
//                Marker marker= Gmap.addMarker(markerOptions);
//                //Add LatLng and Marker
//                latLngList.add(latLng);
//                markerList.add(marker);
//
//            }
//        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case REQUEST_CODE:
                if(grantResults.length>0 && grantResults[0]== PackageManager.PERMISSION_GRANTED){
                    fetchLastLocation();
                }
                break;
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        switch (seekBar.getId()) {
            case R.id.seek_red:
                red = progress;
                break;
            case R.id.seek_blue:
                blue = progress;
                break;
            case R.id.seek_green:
                green = progress;
                break;
        }
        polyline.setColor(Color.rgb(red,green,blue));
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }



}
